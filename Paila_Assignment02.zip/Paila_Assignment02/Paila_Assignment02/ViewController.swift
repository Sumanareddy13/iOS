//
//  ViewController.swift
//  Paila_Assignment02
//
//  Created by Sumanasri Paila on 9/11/23.
//

import UIKit


class ViewController: UIViewController {

    @IBOutlet weak var nameOutlet: UITextField!
    
    @IBOutlet weak var billAmountOutlet: UITextField!
    
    @IBOutlet weak var tipPercentageOutlet: UITextField!
    
    
    
    @IBOutlet weak var nameLabel: UILabel!
    
    
    @IBOutlet weak var billAmountLabel: UILabel!
    
    @IBOutlet weak var tipAmountLabel: UILabel!
    
    @IBOutlet weak var totalAmountLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func SubmitBTN(_ sender: UIButton) {
        let name=nameOutlet.text;
        let billAmount=Double(billAmountOutlet.text!) ?? 0;
        let tipPercentage=Double(tipPercentageOutlet.text!) ?? 0;
        let tipAmount = (billAmount * tipPercentage)/100
        let totalBillAmount = billAmount + tipAmount
        
        nameLabel.text = "Name: "+(name!)
        billAmountLabel.text = "Bill Amount: $\(billAmount)"
        tipAmountLabel.text = "Tip Amount: $\(String(format: "%.2f", tipAmount))"
        totalAmountLabel.text = "Total Amount: $\(String(format: "%.2f", totalBillAmount))"
        
        
    }
    
    @IBAction func ResetBTN(_ sender: UIButton) {
        nameOutlet.text = ""
        billAmountOutlet.text = ""
        tipPercentageOutlet.text = ""
        nameLabel.text = "Name: "
        billAmountLabel.text = "Bill Amount: "
        tipAmountLabel.text = "Tip Amount: "
        totalAmountLabel.text = "Total Amount: "
    }
}

