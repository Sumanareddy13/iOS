//
//  ViewController.swift
//  Paila_SearchApp
//
//  Created by Sumanasri Paila on 10/31/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var searchTextField: UITextField!
    
    
    @IBOutlet weak var resultImage: UIImageView!
    
    
    @IBOutlet weak var topicInfoText: UITextView!
    
    
    @IBOutlet weak var searchBtnOL: UIButton!
    
    @IBOutlet weak var prevBtnOL: UIButton!
    
    @IBOutlet weak var ResetBtnOL: UIButton!
    
    
    @IBOutlet weak var NextBtnOL: UIButton!
    
    @IBOutlet var stackViewBtn: UIView!
    
    
    var ImageArray = [["Bike","Bicycle","Car","Train","Polaris"],
                      ["Prabhas","Maheshbabu","NTR","Akhil","pspk"],
                       ["Biryani","Rasmalai","Maggie","Jamoon","ChickenSandwich"]]
    
    
    var vehicles = ["2 wheeler","no engine","4 wheeler","station","Jeep"]
    var actors = ["Actors","Bahubali","hero","films","entertainment","roles"]
    var Food = ["food","cravings","deserts","hot and spicy","eatables"]
    
    var topic = 0
    
    var imgIndex = 0
    
    var topics=[["A motorcycle is a vehicle used to transport people from one place to another. It does not have 4 wheels like a car. It has 2 wheels like a bicycle, and it has a motor like a car.","A bicycle, also called a pedal cycle, bike, push-bike or cycle, is a human-powered or motor-powered assisted, pedal-driven, single-track vehicle","A car is a means of transport used for traveling from one place to another. This is a four-wheeler used by individuals or family members. We all use cars in our daily lives to go from one place to another for work.","Trains are designed to a certain gauge, or distance between rails. Most trains operate on steel tracks with steel wheels, the low friction of which makes them more efficient than other forms of transpor","Polaris enhances the riding experience with parts, garments, and accessories, along with a growing aftermarket portfolio, including Transamerican Auto Parts."],
        ["Uppalapati Venkata Suryanarayana Prabhas Raju is an Indian actor who predominantly works in Telugu cinema. One of the highest-paid actors in Indian cinema.","Ghattamaneni Mahesh Babu (born 9 August 1975) is an Indian actor, producer, media personality, and philanthropist who works mainly in Telugu cinema.","Nandamuri Taraka Rama Rao Jr. (born 20 May 1983), also known as Jr. N.T.R. or Tarak, is an Indian actor who primarily works in Telugu cinema.","Akhil Akkineni is an American actor of Indian descent known for his works in Telugu cinema. Akhil was born in San Jose, California, and was raised in Hyderabad, India.","Pawan Kalyan is an Indian actor, politician, filmmaker, martial artist, and philanthropist who primarily works in Telugu cinema. Known for his unique acting"],
        ["Biryani is a delicious rice dish peppered with scrumptious spices like saffron and cumin and further layered with spiced meat or veggie protein.","Rasmalai is a popular Indian dessert that originates from the state of Bengal. It is a delightful sweet made from soft and spongy cottage cheese dumplings, also known as 'rasgullas","In 1884, a young visionary named Julius Maggi had an idea: help busy families cook nutritious meals at home. He dreamt of creating food products that would become as ubiquitous as salt and pepper","Gulab jamun is an Indian dessert of fried dough balls that are soaked in a sweet, sticky sugar syrup. As per tradition, the syrup has a delicate rose flavour: Gulab means 'rose water' and jamun refers to a berry of a similar size and colour.","A chicken sandwich is a sandwich that typically consists of boneless, skinless chicken breast or thigh, served between slices of bread, on a bun, or on a roll."]]
    



        
        override func viewDidLoad() {
            super.viewDidLoad()
            utilUIElements()
            
            // Do any additional setup after loading the view.
            
    }

    @IBAction func searchButtonAction(_ sender: UIButton) {
        imgIndex = 0
        topicInfoText.text = ""
        topicInfoText.isUserInteractionEnabled = true
        if(vehicles.contains(searchTextField.text!)) {
            topic = 1
            prevBtnOL.isEnabled = false
            NextBtnOL.isEnabled = true
            stackViewBtn.isHidden = false
            resultImage.image = UIImage(named: ImageArray[0][0])
            topicInfoText.text = topics[0][0]
            
        } else if(actors.contains(searchTextField.text!)) {
            topic = 2
            prevBtnOL.isEnabled = false
            NextBtnOL.isEnabled = true
            stackViewBtn.isHidden = false
            resultImage.image = UIImage(named: ImageArray[1][0])
            topicInfoText.text = topics[1][0]
            
        } else if(Food.contains(searchTextField.text!)) {
            topic = 3
            prevBtnOL.isEnabled = false
            NextBtnOL.isEnabled = true
            stackViewBtn.isHidden = false
            resultImage.image = UIImage(named: ImageArray[2][0])
            topicInfoText.text = topics[2][0]
        } else {
            resultImage.image = UIImage(named: "search not found")
            stackViewBtn.isHidden = true
            topicInfoText.isUserInteractionEnabled = false
        }
    }
        
    
    @IBAction func ShowPrevImageBtn(_ sender: UIButton) {
        imgIndex -= 1
        NextBtnOL.isEnabled = true
        switch topic {
        case 1:
            resultImage.image = UIImage(named: ImageArray[0][imgIndex])
            topicInfoText.text = topics[0][imgIndex]
        case 2:
            resultImage.image = UIImage(named: ImageArray[1][imgIndex])
            topicInfoText.text = topics[1][imgIndex]
        case 3:
            resultImage.image = UIImage(named: ImageArray[2][imgIndex])
            topicInfoText.text = topics[2][imgIndex]
        default:
            print("enter into default")
        }
        
        if(imgIndex == 0) {
            prevBtnOL.isEnabled = false
        } else {
            prevBtnOL.isEnabled = true
        }
    }
    
    @IBAction func ResetBtn(_ sender: UIButton) {
        searchTextField.text = ""
        imgIndex = 0
        utilUIElements()
    }
    
    @IBAction func ShowNextImagesBtn(_ sender: UIButton) {
        imgIndex += 1
        NextBtnOL.isEnabled = true
        prevBtnOL.isEnabled = true
        switch topic {
        case 1:
            resultImage.image = UIImage(named: ImageArray[0][imgIndex])
            topicInfoText.text = topics[0][imgIndex]
        case 2:
            resultImage.image = UIImage(named: ImageArray[1][imgIndex])
            topicInfoText.text = topics[1][imgIndex]
        case 3:
            resultImage.image = UIImage(named: ImageArray[2][imgIndex])
            topicInfoText.text = topics[2][imgIndex]
        default:
            print("enter into default")
        }
        
        if(imgIndex == ImageArray[0].count - 1) {
            NextBtnOL.isEnabled = false
        } else {
            NextBtnOL.isEnabled = true
        }
    }

    @IBAction func toEditTextField(_ sender: UITextField) {
        if searchTextField.text!.isEmpty {
            searchBtnOL.isEnabled = false
        } else {
            searchBtnOL.isEnabled = true
        }
        
    }
   
    
    func utilUIElements() {
        searchBtnOL.isEnabled = false
        resultImage.image = UIImage(named: "welcome")
        topicInfoText.text = ""
        topicInfoText.isUserInteractionEnabled = false
        stackViewBtn.isHidden = true
        topic = 0
    }
    
    
    
}

