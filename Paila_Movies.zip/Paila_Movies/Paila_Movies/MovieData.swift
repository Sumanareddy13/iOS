//
//  MovieData.swift
//  Paila_Movies
//
//  Created by Sumanasri Paila on 11/27/23.
//

import Foundation
import UIKit


struct Movie{
    var title : String
    var image :UIImage
    var releasedYear  : String
    var movieRating : String
    var boxOffice : String
    var moviePlot : String
    var cast = [String]()
}
struct Genre{
    var category :String
    var movies : [Movie] = []
    
}


let movie1 = Genre(category: "Romance", movies: [Movie(title: "Clueless", image: UIImage(named: "clueless")!, releasedYear: "2001", movieRating: "9.5", boxOffice: "244M", moviePlot: "Clueless is a 1995 American coming-of-age teen comedy film written and directed by Amy Heckerling.", cast: ["Alicia","Paul Rudd"]),Movie(title: "Love Today", image: UIImage(named: "Love Today")!, releasedYear: "2022", movieRating: "9.8", boxOffice: "250M", moviePlot: "Uthaman Pradeep, a 24-year-old support engineer employed in Cognizant in Chennai has been in a romantic relationship with Nikitha, daughter of Adv.", cast: ["Pradeep Ranganathan","Ivana"]),Movie(title: "Tholi Prema", image: UIImage(named: "Tholi Prema")!, releasedYear: "2019", movieRating: "10", boxOffice: "500M", moviePlot: "Aditya and Varsha are irresistibly drawn to one another but their individual ideologies keep getting in the way of their romance.", cast: ["Varun Tej","Rashi Kanna"]),Movie(title: "Geetha Govindam", image: UIImage(named: "Geetha Govindam")!, releasedYear: "2018", movieRating: "10", boxOffice: "1B", moviePlot: "At midnight, Nithya's car breaks down and she seeks help from a bypasser Vijay Govind.", cast: ["Vijay Devarakonda","Rashmika Mandanna"]),Movie(title: "Arjun Reddy", image: UIImage(named: "Arjun Reddy")!, releasedYear: "2017", movieRating: "8.9", boxOffice: "430M", moviePlot: "Arjun Reddy Deshmukh is a house surgeon at St. Mary's Medical College in Mangalore, India.", cast: ["Vijay Devarakonda","Shalini Pandey"])]);


let movie2 = Genre(category: "Horror", movies: [Movie(title: "IT", image: UIImage(named: "it")!, releasedYear: "2017", movieRating: "8.9", boxOffice: "431M", moviePlot: "n the Town of Derry, the local kids are disappearing one by one. In a place known as 'The Barrens', a group of seven kids are united by their horrifying scenes", cast: ["Bill","Finn Wolfhard"]),Movie(title: "Talk to me", image: UIImage(named: "talktome")!, releasedYear: "2022", movieRating: "9.2", boxOffice: "312.4M", moviePlot: "The movie explores the consequences of playing with spirits and the manipulation of evil spirits, highlighting that not every lost soul is kind", cast: ["Sophie, Goldie"]),Movie(title: "Chandramukhi", image: UIImage(named: "Chandramukhi")!, releasedYear: "2005", movieRating: "9.4", boxOffice: "554.43M", moviePlot: "Saravanan, a psychiatrist from the United States, comes to meet his friend Senthilnathan, and his wife Ganga while on vacation.", cast: ["Rajinikanth","Jyothika"]),Movie(title: "Gruham", image: UIImage(named: "Gruham")!, releasedYear: "2019", movieRating: "9.1", boxOffice: "432.3M", moviePlot: "The movie starts with a series of incidents of a happy life of mom and a daughter back in 1934.", cast: ["Sidhartha","Andrea Jeremiah"]),Movie(title: "The NUN", image: UIImage(named: "TheNun")!, releasedYear: "2018", movieRating: "8.6", boxOffice: "234.4M", moviePlot: " In 1956 France, a priest is violently murdered, and Sister Irene begins to investigate. She once again comes face-to-face with a powerful evil", cast: ["Taissa","Anna"])]);


let movie3 = Genre(category: "Comedy", movies: [Movie(title: "Hangover", image: UIImage(named: "hangover")!, releasedYear: "2009", movieRating: "9.5", boxOffice: "343.4M", moviePlot: "Three buddies wake up from a bachelor party in Las Vegas, with no memory of the previous night and the bachelor missing", cast: ["Bradley","Zach"]),Movie(title: "Jaathiratnalu", image: UIImage(named: "Jaathiratnalu")!, releasedYear: "2021", movieRating: "9.6", boxOffice: "455M", moviePlot: "Srikanth works in his father's ladies emporium in Jogipet.", cast: ["Naveen Polishetty", "Faria Abdulla"]),Movie(title: "Kithakithalu", image: UIImage(named: "Kithakitalu")!, releasedYear: "2006", movieRating: "9.0", boxOffice: "674M", moviePlot: "Relangi Rajababu is such a that he files a case against a girl who attempted to harass him.", cast: ["Allari Naresh", "Geetha Singh"]),Movie(title: "Aha Na Pelli Anta", image: UIImage(named: "ANPA")!, releasedYear: "1987", movieRating: "9.5", boxOffice: "242.6M", moviePlot: "Satyanarayana is worried about Krishnamurthy's marriage, so much so that he imagines every young woman who happens to be seen by him as his daughter-in-law.", cast: ["Rajendra Prasad","Rajini"]),Movie(title: "Big Stan", image: UIImage(named: "bigstan")!, releasedYear: "2007", movieRating: "8.8", boxOffice: "443.6M", moviePlot: "A weak con man panics when he learns he's going to prison for fraud. He hires a mysterious martial arts guru who helps transform him into a martial arts expert", cast: ["Jennifer","Rob"])]);


var movies_Array = [movie1,movie2,movie3]


