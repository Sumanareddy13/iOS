//
//  MovieCollectionViewCell.swift
//  Paila_Movies
//
//  Created by Sumanasri Paila on 11/27/23.
//

import UIKit

class MovieCollectionViewCell: UICollectionViewCell {
    
    
   
    @IBOutlet weak var imageViewOutlet: UIImageView!
  
    
    func assignMovie(with m: Movie){
            imageViewOutlet.image = m.image
        
    }
    
    
}
