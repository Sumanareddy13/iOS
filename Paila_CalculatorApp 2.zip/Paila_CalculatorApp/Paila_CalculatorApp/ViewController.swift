//
//  ViewController.swift
//  Paila_CalculatorApp
//
//  Created by Sumanasri Paila on 9/26/23.
//

import UIKit

class ViewController: UIViewController {
            var isOkay = false
            var num1:Double=0;
            var num2:Double=0;
            var opr = ""
            var isNotOkay=false

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBOutlet weak var resultOutlet: UILabel!
    
    
    @IBAction func buttonAC(_ sender: UIButton) {
        num1=0
               num2=0
               opr=""
               resultOutlet.text=""
               isOkay=false
               isNotOkay=false
    }
    
    
    @IBAction func buttonC(_ sender: UIButton) {
        resultOutlet.text="0"
                isOkay=false
    }
    
    @IBAction func buttonChange(_ sender: UIButton) {
        if isOkay{
                            isNotOkay = !isNotOkay
                            if isNotOkay{
                                resultOutlet.text = "-" + resultOutlet.text!
                            }
                            else{
                                resultOutlet.text!.removeFirst()
                            }
                        }
    }
    
    @IBAction func buttonDivision(_ sender: UIButton) {
        handleOperator("÷")
    }
    
    @IBAction func buttonSeven(_ sender: UIButton) {
        appendDigit(7)
    }
    
    @IBAction func buttonEight(_ sender: UIButton) {
        appendDigit(8)
    }
    
    @IBAction func buttonNine(_ sender: UIButton) {
        appendDigit(9)
    }
    
    @IBAction func buttonMultiply(_ sender: UIButton) {
        handleOperator("*")
    }
    
    @IBAction func buttonFour(_ sender: UIButton) {
        appendDigit(4)
    }
    
    @IBAction func buttonFive(_ sender: UIButton) {
        appendDigit(5)
    }
    
    @IBAction func buttonSix(_ sender: UIButton) {
        appendDigit(6)
    }
    
    @IBAction func buttonMinus(_ sender: UIButton) {
        handleOperator("-")
    }
    
    @IBAction func buttonOne(_ sender: UIButton) {
        appendDigit(1)
    }
    
    @IBAction func buttonTwo(_ sender: UIButton) {
        appendDigit(2)
    }
    
    @IBAction func buttonThree(_ sender: UIButton) {
        appendDigit(3)
    }
    
    @IBAction func buttonPlus(_ sender: UIButton) {
        handleOperator("+")
    }
    
    @IBAction func buttonZero(_ sender: UIButton) {
        appendDigit(0)
    }
    
    @IBAction func buttonFraction(_ sender: UIButton) {
        if isOkay && !resultOutlet.text!.contains(".") {
            resultOutlet.text! += "."
        }
        else if !isOkay {
            resultOutlet.text = "0."
            isOkay=true
        }
    }
    
    @IBAction func buttonPercentage(_ sender: UIButton) {
        handleOperator("%")
    }
    
    @IBAction func buttonEquals(_ sender: UIButton) {
        if isOkay{
                            let opr1 = Double(resultOutlet.text!) ?? 0
                            
                            switch opr{
                            case "+":
                                num1 += opr1
                                
                            case "-":
                                num1 -= opr1
                                
                            case "*":
                                num1 *= opr1
                                
                            case "÷":
                                if opr1 != 0 {
                                    num1 /= opr1
                                } else {
                                    resultOutlet.text = "Not a number"
                                    return
                                }
                                
                            case "%":
                                num1 = num1.truncatingRemainder(dividingBy: opr1)
                                
                            default:
                                break
                            }
                                resultOutlet.text = formatResult(num1)
                                
                                isOkay = false
                                isNotOkay = false
                }
                        }
                        //func clearText(){
                        //    resultOutlet.text=""
                        // }
                        func appendDigit(_ digit: Int) {
                            if isOkay{
                                if resultOutlet.text == "0" || resultOutlet.text == "-0" {
                                    if digit != 0 {
                                        resultOutlet.text = isNotOkay ? "-" + "\(digit)" : "\(digit)"
                                    }
                                } else {
                                    resultOutlet.text! += "\(digit)"
                                }
                            } else {
                                resultOutlet.text = isNotOkay ? "-" + "\(digit)":"\(digit)"
                                isOkay = true
                            }
                                    }
                                    func handleOperator(_ operatorSymbol: String) {
                                        if isOkay {
                                            let value = resultOutlet.text!
                                            num1 = Double(value) ?? 0
                                            isOkay = false
                                        }
                                        opr = operatorSymbol
                                        isNotOkay=false
                                    }

                                            func formatResult(_ number: Double) -> String {
                                                let roundOf = round(number * 100000) / 100000
                                                if roundOf.truncatingRemainder(dividingBy: 1) == 0 {
                                                    return String(format: "%.0f", roundOf)
                                                } else {
                                                    return String(roundOf)
                                                }
                                            }
              }

