//
//  ViewController.swift
//  Paila_WordGuess
//
//  Created by Sumanasri Paila on 10/19/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var wordsGuessedLabel: UILabel!
    
    @IBOutlet weak var wordsRemainingLabel: UILabel!
    
    @IBOutlet weak var totalWordsLabel: UILabel!
    
    @IBOutlet weak var userGuessLabel: UILabel!
    
    @IBOutlet weak var hintLabel: UILabel!
    
    @IBOutlet weak var guessCountLabel: UILabel!
    
    @IBOutlet weak var statusLabel: UILabel!
    
    @IBOutlet weak var displayImage: UIImageView!
    
    @IBOutlet weak var guessLetterField: UITextField!
    
    @IBOutlet weak var playAgainButton: UIButton!
    
    @IBOutlet weak var guessALetterButtton: UIButton!
    
    
    var arrayOfWords = [["TITANIC", "A tragic real story"],["VANILLA", "Icecream flavour"], ["SMILEY", "Emoji"], ["LION", "King of Forest"],         ["FLORIDA", "Disney World located in"]  ]
    
    var wordsImageArray = ["titanic", "vanilla", "smiley", "lion", "florida"]
    
    var c = 0;
    
    var word = ""
    
    var lettersGuessed = ""
    
    var countOfGuesses = 0
    
    let maximumNumOfWrongGuesses = 10
    
    var wordCount = 0
    
    var remainingWordCount = 5
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        guessALetterButtton.isEnabled = false
        playAgainButton.isHidden = true
        statusLabel.text = ""
        wordsGuessedLabel.text!  +=  "0"
        wordsRemainingLabel.text!  +=  "5"
        totalWordsLabel.text!  +=  String(arrayOfWords.count)
        word = arrayOfWords[c][0]
        hintLabel.text = "Hint: "+arrayOfWords[c][1]
        userGuessLabel.text = ""
        underscoreUpdate()
        
    }
    
    @IBAction func guessLetterButtonPressed(_ sender: UIButton) {
        let letter = guessLetterField.text!
        countOfGuesses  +=  1
        lettersGuessed  +=  letter
        var revealedWord = ""
        print(letter)
        for i in word{
            if lettersGuessed.contains(i){
                revealedWord += "\(i)"
                print(revealedWord)
            }
            else{
                revealedWord  +=  "_ "
            }
        }
       
        userGuessLabel.text = revealedWord
        guessLetterField.text = ""
        guessCountLabel.text = "You have made \(countOfGuesses) guesses"
        
        if userGuessLabel.text!.contains("_") == false{
            wordCount  +=  1
            remainingWordCount  -=  1
            playAgainButton.isHidden = false;
            guessALetterButtton.isEnabled = false;
            displayImage.image = UIImage(named: wordsImageArray[c])
            guessCountLabel.text = "Wow! you have made \(countOfGuesses) guesses to guess the word"
            wordsGuessedLabel.text! = "Total number of words guessed successfully: " + "\(wordCount)"
            wordsRemainingLabel.text! = "Total number of words remaining in game: " + "\(remainingWordCount)"
        }
        
        if(countOfGuesses > 10) {
            playAgainButton.isHidden = false
            guessCountLabel.text = "You have used all the available guessess, Please Play Again"
            c -= 1
        }
        guessALetterButtton.isEnabled = false

    }
    
    
    @IBAction func playAgainButtonPressed(_ sender: UIButton) {
    
        playAgainButton.isHidden = true
        displayImage.image = nil
        countOfGuesses = 0
        guessCountLabel.text = "You have made \(countOfGuesses) guesses"
        
        lettersGuessed = ""
        c += 1
        
        if c == arrayOfWords.count{
            statusLabel.text = "Congruations! You are done with the game!"
            displayImage.image = UIImage(named: "alldone")
            playAgainButton.isHidden = false
            userGuessLabel.text = ""
            hintLabel.text = ""
            guessCountLabel.text = ""
            c = -1
        }
        else{
            statusLabel.text = ""
            word = arrayOfWords[c][0]
            
            hintLabel.text = "Hint: "
            hintLabel.text! += arrayOfWords[c][1]
            
            guessALetterButtton.isEnabled = true
            
            userGuessLabel.text = ""
            underscoreUpdate()
        }
    }
    
    
    @IBAction func editingChangesTxtField(_ sender: UITextField) {
        
        var textEntered = guessLetterField.text!
        
        textEntered = String(textEntered.last ?? " ").trimmingCharacters(in: .whitespaces)
        guessLetterField.text = textEntered
        if(guessLetterField.text!.isEmpty) {
            
            guessALetterButtton.isEnabled = false
        } else {
            
            guessALetterButtton.isEnabled = true
            
        }
    }
    
    func underscoreUpdate() {
        
        for _ in 0..<word.count {
            userGuessLabel.text! += "_ "
        }
    }
}
