//
//  UniversityInfoViewController.swift
//  Paila_UniversityApp
//
//  Created by Sumanasri Paila on 11/16/23.
//

import UIKit

class UniversityInfoViewController: UIViewController {
    
    
    var university : college?
        var img_info = ""
        var lab_info = ""
        var name_info = ""

    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = university?.universityName
                print(university)

        // Do any additional setup after loading the view.
        universityInfoOutlet.isHidden = true
    }
    
    override func viewDidAppear(_ animated: Bool) {
        universityImageViewOutlet.image = UIImage(named:(university?.image)!)
        universityImageViewOutlet.frame.origin.x = view.frame.maxX
        UIView.animate(withDuration: 1, animations: {
            self.universityImageViewOutlet.center.x = self.view.center.x})
        
    }
    
    
    @IBOutlet weak var universityImageViewOutlet: UIImageView!
    
    
    @IBOutlet weak var universityInfoOutlet: UITextView!
    

        
    @IBAction func showInfoAction(_ sender: UIButton) {
        universityInfoOutlet.isHidden = false
        universityInfoOutlet.text! = (university?.universityinfo)!
        print(name_info)
    }
    

}
