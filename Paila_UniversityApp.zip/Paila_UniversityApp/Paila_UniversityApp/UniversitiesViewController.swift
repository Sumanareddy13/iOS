//
//  ViewController.swift
//  Paila_UniversityApp
//
//  Created by Sumanasri Paila on 11/16/23.
//

import UIKit


class Domain{
    var domainName : String?
    var universityName : [UniversityList]?
    
    init(domainName : String , universityName : [UniversityList]){
        self.domainName = domainName
        self.universityName = universityName
    }
}
var n = 0
class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return domain_arr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = universitiesTableView.dequeueReusableCell(withIdentifier: "domainCell", for: indexPath)
        cell.textLabel?.text = domain_arr[indexPath.row].domain
        
        return cell
    }
    
    
    @IBOutlet weak var universitiesTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        universitiesTableView.delegate = self
        universitiesTableView.dataSource = self
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "listsSegue"{
            let destination = segue.destination as! UniversityListViewController
            destination.universities = domain_arr[(universitiesTableView.indexPathForSelectedRow?.row)!]
        }
    }
}

