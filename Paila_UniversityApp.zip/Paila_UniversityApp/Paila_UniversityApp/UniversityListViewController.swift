//
//  UniversityListViewController.swift
//  Paila_UniversityApp
//
//  Created by Sumanasri Paila on 11/16/23.
//

import UIKit

class college{
    var universityName : String?
    var image : String?
    var universityinfo : String?
    
    init(universityName : String,image : String,universityinfo : String){
        self.universityName = universityName;
        self.image = image;
        self.universityinfo = universityinfo;
    }
}
var img_name = ""
var desc = ""
var uni_name = ""
var unvrsty = [college]()

class UniversityListViewController: UIViewController , UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return domain_arr[0].list.count
    }
   
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = universityListTableView.dequeueReusableCell(withIdentifier: "listCell", for: indexPath)
        
        cell.textLabel?.text = universities?.list[indexPath.row].collegeName
        
        uni_name = (universities?.list[indexPath.row].collegeName)!
        
        img_name = (universities?.list[indexPath.row].universityImg)!
        
        desc = (universities?.list[indexPath.row].universityInfo)!
        var output = college(universityName: uni_name, image: img_name, universityinfo: desc)
        unvrsty.append(output)
        print(img_name+"----------------------------"+desc+uni_name)
        
        return cell
    }
    
    @IBOutlet weak var universityListTableView: UITableView!
    
    
    var universities : Universities?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        universityListTableView.delegate = self
        universityListTableView.dataSource = self
    }
    

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            let transition = segue.identifier
         if(transition == "universityInfoSegue"){
             let destination = segue.destination as! UniversityInfoViewController
             destination.university = unvrsty[(universityListTableView.indexPathForSelectedRow?.row)!]
                           //destination.university = l
             //destination.lab = tableView(UITableView, cellForRowAt: IndexPath)
             //destination.nam = co
         }
        }

}
