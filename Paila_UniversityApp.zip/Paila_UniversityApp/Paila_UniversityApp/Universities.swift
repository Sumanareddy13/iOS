//
//  Universities.swift
//  Malli_UniversityApp
//
//  Created by Malli,Bhavana on 4/20/23.
//

import Foundation

struct Universities {
    var domain = ""
    var list : [UniversityList] = []
    
}
struct UniversityList{
    var collegeName:String = ""
    var universityImg  = ""
    var universityInfo  = ""
}
var domain1 = Universities(domain : "Computer Science",list: [UniversityList(collegeName : "Princeton University",universityImg: "princeton",universityInfo: "Princeton University is a private Catholic university in Erie, Pennsylvania. Gannon University has approximately 4,500 students and 46,000 alumni. Its intercollegiate athletics include 18 athletic programs for men and women competing at the NCAA Division II level. "),UniversityList(collegeName : "The University of Texas at Arlington",universityImg: "UTA",universityInfo: "The University of Texas at Arlington is a public research university in Arlington, Texas. The university was founded in 1895 and was in the Texas A&M University System for several decades until joining the University of Texas System in 1965."),UniversityList(collegeName : "University of Houston",universityImg: "UH",universityInfo: "The University of Houston is a public research university in Houston, Texas. Founded in 1927, UH is a member of the University of Houston System and the third-largest university in Texas with over 47,000 students.")])

var domain2 = Universities(domain : "Data Science",list: [UniversityList(collegeName : "University of Chicago",universityImg: "UC",universityInfo: "University of Chicago is a private institution that was founded in 1890. It has a total undergraduate enrollment of 7,526 (fall 2021), its setting is urban, and the campus size is 217 acres. It utilizes a quarter-based academic calendar. University of Chicago's ranking in the 2022-2023 edition of Best Colleges is National Universities, #6. Its tuition and fees are $62,940."),UniversityList(collegeName : "Stanford University",universityImg: "stanford",universityInfo: "Duke University is a private institution that was founded in 1838. It has a total undergraduate enrollment of 6,883 (fall 2021), its setting is suburban, and the campus size is 8,693 acres. It utilizes a semester-based academic calendar. Duke University's ranking in the 2022-2023 edition of Best Colleges is National Universities, #10. Its tuition and fees are $63,054."),UniversityList(collegeName : "Texas A&M Corpus Christi",universityImg: "TAMUCC",universityInfo: "University of Texas at corpus  is a public institution that was founded in 1883. It has a total undergraduate enrollment of 40,916 (fall 2021), its setting is urban, and the campus size is 431 acres. It utilizes a semester-based academic calendar. University of Texas at Austin's ranking in the 2022-2023 edition of Best Colleges is National Universities, #38.")])

var domain3 = Universities(domain : "Information Technology",list: [UniversityList(collegeName : "Harvard University",universityImg: "harvard",universityInfo: "Founded in 1901 in San Francisco, California, University focuses on graduate and undergraduate education in business, law, taxation, and accounting. A private, nonprofit institution of higher learning, GGU grants a master of science in information technology management, fitting for learners looking to extend and further develop their expertise in the field."),UniversityList(collegeName : "Yale University",universityImg: "YU",universityInfo: "Yale University is a private Ivy League research university in New Haven, Connecticut. Founded in 1701, Yale is the third-oldest institution of higher education in the United States and one of the nine colonial colleges chartered before the American Revolution.")])

var domain4 = Universities(domain : "Information Systems",list: [UniversityList(collegeName : "Yale University",universityImg: "YU",universityInfo: "Yale University is a private Ivy League research university in New Haven, Connecticut. Founded in 1701, Yale is the third-oldest institution of higher education in the United States and one of the nine colonial colleges chartered before the American Revolution."),UniversityList(collegeName : "NORTWEST MISSOURI STATE UNIVERSITY",universityImg: "nwmsu",universityInfo: "Northwest Missouri State University is a public university in Maryville, Missouri. It has an enrollment of about 8,505 students. Founded in 1905 as a teachers college, its campus is based on the design for Forest Park at the 1904 St. Louis World's Fair and is the official Missouri State Arboretum."),UniversityList(collegeName : "University of Central Missouri",universityImg: "UCM",universityInfo: "The University of Central Missouri is a public university in Warrensburg, Missouri. In 2019, enrollment was 11,229 students from 49 states and 59 countries on its 1,561-acre campus. UCM offers 150 programs of study, including 10 pre-professional programs, 27 areas of teacher certification, and 37 graduate programs.")])


var domain_arr = [domain1, domain2, domain3, domain4]
